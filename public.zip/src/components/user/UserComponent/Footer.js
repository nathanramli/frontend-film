import React from 'react';
import Container from '@material-ui/core/Container';
import { makeStyles } from '@material-ui/core/styles';
const useStyles = makeStyles(theme =>({
  containerAnime:{
  	backgroundColor:'transparent',
  	padding:'0',
  	color:'#e53935',
  	borderRadius:'4px',
  	height: 'auto',
  	marginTop:'20px',
  	marginBottom:'20px',
  	[theme.breakpoints.only('xs')]:{
  		marginTop:'0px',
  		marginBottom:'0px',
  	},
  },
  containerFooter:{
  	backgroundColor:'#37474F',
  	height:'100px',
  	marginBottom:'0px',

  	padding:'1px',
  	[theme.breakpoints.only('xs')]:{
  		height:'70px',
  	},
  },
  divGan:{
  	marginTop:'20px',
  	textAlign:'center',
  	 color:'white',
  	fontWeight:'bold',
  	fontSize:'24px',
  },
  divGan2:{
  	marginTop:'20px',
  	paddingLeft:'10px',
  	textAlign:'left',
  	 color:'white',
  	fontWeight:'bold',
  	fontSize:'14px',
  }
}));
const Footer = () =>{
	const classes = useStyles();
	return(
		<Container maxWidth="xl" component="div" className={classes.containerFooter}>
	    	<div className={classes.divGan}>
	    		Fansnime
	    	</div>
	    	<div className={classes.divGan2}>
	    		&copy; 2019, Fansnime.com
	    	</div>
	    </Container> 
	);
}

export default Footer;
