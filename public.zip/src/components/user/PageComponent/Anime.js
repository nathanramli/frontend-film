import React, {Component} from 'react';
import axios from 'axios';
import {Link as RouterLink } from 'react-router-dom';
import Loading from './../UserComponent/Loading';
import RecipeReviewCard from './../UserComponent/AnimeCard';

import Button from '@material-ui/core/Button';
import Sync from '@material-ui/icons/Sync';
import Completed from '@material-ui/icons/CheckCircle';
import NavigateNextIcon from '@material-ui/icons/NavigateNext';
import Movie from '@material-ui/icons/Movie';
import Grid from '@material-ui/core/Grid';
import {withStyles} from '@material-ui/core/styles';


const API_URL = 'https://api.fansnime.com';

const styles = theme =>({
	NavigateNextIcon:{
		marginLeft: theme.spacing(1),
	},
	fontResponsiveTitle:{
		color:'white',
		fontSize:'18px',
		fontWeight:'600',
		[theme.breakpoints.only('xs')]:{
			fontSize:'12px',
		}
	},
	buttonSeeMore:{
		float:'right',
		marginRight:'10px',
		fontWeight:'bold',
		[theme.breakpoints.only('xs')]:{
			fontSize:'12px',
			marginBottom:'5px',
		}
	},
	buttonSeeMoreComplete:{
		float:'right',
		marginRight:'10px',
		fontWeight:'bold',
		[theme.breakpoints.only('xs')]:{
			fontSize:'12px',
			float:'left',
			marginBottom:'5px',
			marginLeft:'5px',

		}
	}
})

class Anime extends Component {
		state = {
		  complete: [],
		  ongoing: [],
		  movie: [],
          loading: 1
		}

		componentDidMount() {
			const url = `${API_URL}/api/film_limit_enam/`;
        	axios.get(url, {
            onDownloadProgress: (progressEvent) => {
					if(progressEvent.lengthComputable){
						let percent = Math.round((progressEvent.loaded * 100) / progressEvent.total);
						this.setState({loading: this.state.loading+percent});                
					}else{
						this.setState({loading: 100});
					}
	            }
          	}).then((response) => {
          		let complete = [];
          		let movie = [];
          		let ongoing = [];
        		let result = response.data;
        		result.data.forEach(function(row){  
        			switch(row.jenis){
        				case "o":
	        				ongoing.push(row);
	        				break;
	        			case "m":
        					movie.push(row);
        					break;
	        			case "c":
	        				complete.push(row);
	        				break;
	        			default:
	        				break;
	        		}
        		});

        		this.setState({ongoing: ongoing});
        		this.setState({complete: complete});
        		this.setState({movie: movie});
		    });
		}

		render() {        
			return(
	          	<React.Fragment>
	          	<Loading progress={this.state.loading}/>				
				<Grid container style={{marginTop: '10px',backgroundColor:'white',borderRadius:'2px',padding:'10px'}} > 
					<Grid item xs={12} style={{backgroundColor:'#e53935',padding:0,color:'white'}}>
                        <div style={{marginTop:'5px'}}>
                        	<Button disabled style={{color:'white'}} className={this.props.classes.fontResponsiveTitle}>
                        		<Sync /> ONGOING ANIME
                        	</Button>
                        	<Button style={{color:'white',backgroundColor:'#f57f17'}} component={RouterLink} to="/ongoing" className={this.props.classes.buttonSeeMore}>
                        		See More
                        		<NavigateNextIcon className={this.props.classes.NavigateNextIcon}/>
                        	</Button>
                        </div>
					</Grid>
					{this.state.ongoing.map(row => 
						<Grid item xs={12} sm={6} md={4} lg={3} key={row.pk} style={{padding: 10}}>
							<RecipeReviewCard judul={row.judul} gambar={row.gambar} link={row.kode}/>
						</Grid>
					)}
				</Grid>
				<Grid container style={{marginTop: '10px',backgroundColor:'white',borderRadius:'2px',padding:'10px'}}> 
					<Grid item xs={12} style={{backgroundColor:'#f57f17',padding:0,color:'#e53935'}}>
			            <div style={{marginTop:'5px'}}>
			            	<Button disabled style={{color:'white'}} className={this.props.classes.fontResponsiveTitle}>
			            		<Completed /> COMPLETED ANIME SERIES
			            	</Button>
			            	<Button style={{backgroundColor:'#aeea00',color:'white'}} component={RouterLink} to="/complete" className={this.props.classes.buttonSeeMoreComplete}>
                        		See More
                        		<NavigateNextIcon className={this.props.classes.NavigateNextIcon}/>
                        	</Button>
			            </div>
					</Grid>
					{this.state.complete.map(row => 
						<Grid item xs={12} sm={6} md={4} lg={3} key={row.pk} style={{padding: 10}}>
							<RecipeReviewCard judul={row.judul} gambar={row.gambar} link={row.kode}/>
						</Grid>
					)}
				</Grid>
				<Grid container style={{marginTop: '10px',backgroundColor:'white',borderRadius:'2px',padding:'10px'}}> 
					<Grid item xs={12} style={{backgroundColor:'#aeea00',padding:0,color:'#e53935'}}>
		                <div style={{marginTop:'5px'}}>
		                	<Button disabled style={{color:'white'}} className={this.props.classes.fontResponsiveTitle}>
		                		<Movie /> ANIME MOVIE
		                	</Button>
		                	<Button style={{backgroundColor:'#e53935',color:'white'}} component={RouterLink} to="/movie" className={this.props.classes.buttonSeeMore}>
                        		See More
                        		<NavigateNextIcon className={this.props.classes.NavigateNextIcon}/>
                        	</Button>
		                </div>
					</Grid>
					{this.state.movie.map(row => 
						<Grid item xs={12} sm={6} md={4} lg={3} key={row.pk} style={{padding: 10}}>
							<RecipeReviewCard judul={row.judul} gambar={row.gambar} link={row.kode}/>
						</Grid>
					)}
				</Grid>
				</React.Fragment>
			);
		}
}


export default withStyles(styles)(Anime);