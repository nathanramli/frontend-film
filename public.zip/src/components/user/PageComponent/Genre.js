import React, { Component } from 'react';
import {Link as RouterLink} from 'react-router-dom';

import Grid from '@material-ui/core/Grid';
import {withStyles} from '@material-ui/core/styles';

const styles = theme =>({
	gridItem:{
		backgroundColor:'#263238',
		textAlign:'center',
		marginLeft:'33px',
		marginTop:'15px',
		padding:'15px',
		borderRadius:'2px',
		[theme.breakpoints.only('xs')]:{
			marginLeft:'25px',
			padding:'8px',
			fontSize:'10px',
		}
	}
})
class Genre extends Component {
	constructor(props){
		super(props);
		this.state = {
			genre:[
			{nama:'Action',warna:'#ff5252',link:'genre/action'},
			{nama:'Adventure',warna:'#ff7474',link:'genre/adventure'},
			{nama:'Comedy',warna:'#ff4081',link:'genre/comedy'},
			{nama:'Dementia',warna:'#ff669a',link:'genre/dementia'},
			{nama:'Demons',warna:'#e040fb',link:'genre/demons'},
			{nama:'Drama',warna:'#e666fb',link:'genre/drama'},
			{nama:'Ecchi',warna:'#7c4dff',link:'genre/ecchi'},
			{nama:'Fantasy',warna:'#9670ff',link:'genre/fantasy'},
			{nama:'Game',warna:'#536dfe',link:'genre/game'},
			{nama:'Harem',warna:'#758afe',link:'genre/harem'},
			{nama:'Historical',warna:'#448aff',link:'genre/historical'},
			{nama:'Horror',warna:'#69a1ff',link:'genre/horror'},
			{nama:'Josei',warna:'#40c4ff',link:'genre/josei'},
			{nama:'Kids',warna:'#66cfff',link:'genre/kids'},
			{nama:'Magic',warna:'#18ffff',link:'genre/magic'},
			{nama:'Martial Arts',warna:'#46ffff',link:'genre/martial-arts'},
			{nama:'Mecha',warna:'#64ffda',link:'genre/mecha'},
			{nama:'Military',warna:'#83ffe1',link:'genre/military'},
			{nama:'Music',warna:'#69f0ae',link:'genre/music'},
			{nama:'Mystery',warna:'#87f3be',link:'genre/mystery'},
			{nama:'Parody',warna:'#b2ff59',link:'genre/parody'},
		    {nama:'Police',warna:'#c1ff7a',link:'genre/police'},
            {nama:'Psychological',warna:'#eeff41',link:'genre/psychological'},
            {nama:'Romance',warna:'#f1ff67',link:'genre/romance'},
            {nama:'Samurai',warna:'#ffff00',link:'genre/samurai'},
            {nama:'School',warna:'#ffff33',link:'genre/school'},
            {nama:'Sci-Fi',warna:'#ffd740',link:'genre/sci-fi'},
            {nama:'Seinen',warna:'#ffdf66',link:'genre/seinen'},
            {nama:'Shoujo',warna:'#ffab40',link:'genre/shoujo'},
            {nama:'Shoujo Ai',warna:'#ffbb66',link:'genre/shoujo-ai'},
            {nama:'Shounen',warna:'#ff6e40',link:'genre/shounen'},
            {nama:'Slice Of Life',warna:'#ff8b66',link:'genre/slice-of-life'},
            {nama:'Space',warna:'#5635b2',link:'genre/space'},
            {nama:'Sports',warna:'#3a4cb1',link:'genre/sports'},
            {nama:'Super Power',warna:'#2f60b2',link:'genre/super-power'},
            {nama:'Supernatural',warna:'#2c89b2',link:'genre/supernatural'},
            {nama:'Thriller',warna:'#b22c5a',link:'genre/thriller'},
            {nama:'Vampire',warna:'#9c2caf',link:'genre/vampire'},
		 ],
		}
	}
	render(){	
		return(
			<Grid container style={{backgroundColor:'white',padding:'20px'}}>
				{this.state.genre.map(row =>
					<Grid component={RouterLink} to={{pathname:`/${row.link}`}} item xs={4} md={2} lg={2} xl={2} key={row} className={this.props.classes.gridItem}  style={{border: `3px solid ${row.warna}`,boxShadow: `0 0 10px ${row.warna}`,color:`${row.warna}`,textShadow:'-0px -0px -10px #000,  1px -1px 0 #000,-1px 1px 0 #000,1px 1px 0 #000',textDecoration:'none'}}>
						{row.nama}
					</Grid>
				)}
			</Grid>
		);
	}
}
export default withStyles(styles)(Genre);