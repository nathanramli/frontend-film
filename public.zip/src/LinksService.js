import axios from 'axios';
const API_URL = 'https://api.fansnime.com';

export default class LinksService{
    getLinks(id_film) {
        const url = `${API_URL}/api/link/${id_film}`;
        return axios.get(url).then(response => response.data);
    }
    createLink(link){
        const url = `${API_URL}/api/link/`;
        return axios.post(url,link);
    }    
}